export { default } from "./TotalToInvest";
