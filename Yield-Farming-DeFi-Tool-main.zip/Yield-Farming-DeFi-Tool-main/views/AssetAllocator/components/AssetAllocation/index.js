export { default } from "./AssetAllocation";
