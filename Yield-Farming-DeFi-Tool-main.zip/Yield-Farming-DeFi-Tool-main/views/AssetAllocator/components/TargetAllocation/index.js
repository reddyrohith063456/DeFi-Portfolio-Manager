export { default } from "./TargetAllocation";
