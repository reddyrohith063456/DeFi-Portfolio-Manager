import React from "react";
import ConnectionPendingModal from "./ConnectionPendingModal";
import LoadingAssetsModal from "./LoadingAssetsModal";

const Modals = () => {
  return <ConnectionPendingModal />;
};

export default Modals;
