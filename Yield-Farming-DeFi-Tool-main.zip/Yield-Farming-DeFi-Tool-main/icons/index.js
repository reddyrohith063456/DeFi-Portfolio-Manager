export { default as Facebook } from "./Facebook";
export { default as Google } from "./Google";
export { default as Gold } from "./Gold";
export { default as Crypto } from "./Crypto";
